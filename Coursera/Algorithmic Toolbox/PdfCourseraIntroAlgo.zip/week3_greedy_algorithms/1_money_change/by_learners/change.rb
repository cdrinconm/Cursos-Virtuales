#!/usr/bin/env ruby
# by Andronik Ordian

def get_change(n)
  count = 0
  coins = [1, 5, 10]
  # write your code here
  count
end

if __FILE__ == $0
  n = gets.to_i
  puts "#{get_change(n)}"   
end
